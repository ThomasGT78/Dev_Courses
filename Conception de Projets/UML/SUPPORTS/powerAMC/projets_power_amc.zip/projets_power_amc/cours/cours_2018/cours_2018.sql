/*==============================================================*/
/* Nom de SGBD :  MySQL 5.0                                     */
/* Date de cr�ation :  07/09/2018 14:59:07                      */
/*==============================================================*/


drop table if exists Clients;

drop table if exists Entreprises;

drop table if exists Particuliers;

drop table if exists Pays;

drop table if exists Villes;

/*==============================================================*/
/* Table : Clients                                              */
/*==============================================================*/
create table Clients
(
   idClient             int not null,
   idVille              int not null,
   nomClient            varchar(254),
   primary key (idClient)
);

/*==============================================================*/
/* Table : Entreprises                                          */
/*==============================================================*/
create table Entreprises
(
   idClient             int not null,
   idEntreprise         int not null,
   siren                varchar(254),
   primary key (idClient, idEntreprise)
);

/*==============================================================*/
/* Table : Particuliers                                         */
/*==============================================================*/
create table Particuliers
(
   idClient             int not null,
   idParticulier        int not null,
   dateNaissance        datetime,
   primary key (idClient, idParticulier)
);

/*==============================================================*/
/* Table : Pays                                                 */
/*==============================================================*/
create table Pays
(
   idPays               int not null,
   nomPays              varchar(254),
   primary key (idPays)
);

/*==============================================================*/
/* Table : Villes                                               */
/*==============================================================*/
create table Villes
(
   idVille              int not null,
   idPays               int not null,
   nomVille             varchar(254),
   cp                   varchar(254),
   primary key (idVille)
);

alter table Clients add constraint FK_habiter foreign key (idVille)
      references Villes (idVille) on delete restrict on update restrict;

alter table Particuliers add constraint FK_Generalisation_1 foreign key (idClient)
      references Clients (idClient) on delete restrict on update restrict;

alter table Villes add constraint FK_villes_dans_pays foreign key (idPays)
      references Pays (idPays) on delete restrict on update restrict;

