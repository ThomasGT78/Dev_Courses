/***********************************************************************
 * Module:  Utilisateurs.java
 * Author:  Administrateur
 * Purpose: Defines the Class Utilisateurs
 ***********************************************************************/

import java.util.*;

/** @pdOid 747a3a8b-8d6c-4c87-a678-63320b3e8289 */
public class Utilisateurs {
   /** @pdOid 1323063d-6e69-4047-8811-bddcdb113584 */
   private int idUt;
   /** @pdOid c6be6a55-94f4-4263-9d45-9d677c9198b0 */
   private String nomUt;
   /** @pdOid bfeb9199-4d84-4640-a57a-f1702cb9f29f */
   private String emailUt;
   /** @pdOid 8bc72958-6bbb-4b76-8a84-0f83c4210740 */
   private String pwd;

}