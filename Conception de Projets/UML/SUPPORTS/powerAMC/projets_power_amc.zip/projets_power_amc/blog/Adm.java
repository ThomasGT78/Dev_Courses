/***********************************************************************
 * Module:  Adm.java
 * Author:  Administrateur
 * Purpose: Defines the Class Adm
 ***********************************************************************/

import java.util.*;

/** @pdOid 592659f4-5962-4138-b407-9a426315c87e */
public class Adm {
   /** @pdOid 01e2ecd8-70dd-44ca-950d-f349053c61dd */
   private int idAdm;
   /** @pdOid 3d5975a8-8f98-4e01-b266-b61617d23520 */
   private String nomAdm;

}