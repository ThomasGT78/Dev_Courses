/*==============================================================*/
/* Nom de SGBD :  MySQL 5.0                                     */
/* Date de cr�ation :  07/09/2018 16:09:31                      */
/*==============================================================*/


drop table if exists Adm;

drop table if exists Articles;

drop table if exists Commentaires;

drop table if exists Utilisateurs;

/*==============================================================*/
/* Table : Adm                                                  */
/*==============================================================*/
create table Adm
(
   idAdm                int not null,
   nomAdm               varchar(254),
   primary key (idAdm)
);

/*==============================================================*/
/* Table : Articles                                             */
/*==============================================================*/
create table Articles
(
   idArticle            int not null,
   idUt                 int not null,
   texteArticle         varchar(254),
   datePublication      datetime,
   primary key (idArticle)
);

/*==============================================================*/
/* Table : Commentaires                                         */
/*==============================================================*/
create table Commentaires
(
   idCommentaire        int not null,
   idArticle            int not null,
   texteCommentaire     varchar(254),
   dateCommentaire      datetime,
   emailCommentaire     varchar(254),
   primary key (idCommentaire)
);

/*==============================================================*/
/* Table : Utilisateurs                                         */
/*==============================================================*/
create table Utilisateurs
(
   idUt                 int not null,
   nomUt                varchar(254),
   emailUt              varchar(254),
   pwd                  varchar(254),
   primary key (idUt)
);

alter table Articles add constraint FK_ecrire foreign key (idUt)
      references Utilisateurs (idUt) on delete restrict on update restrict;

alter table Commentaires add constraint FK_commenter foreign key (idArticle)
      references Articles (idArticle) on delete restrict on update restrict;

