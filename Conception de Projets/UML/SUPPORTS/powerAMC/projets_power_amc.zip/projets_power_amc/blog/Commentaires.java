/***********************************************************************
 * Module:  Commentaires.java
 * Author:  Administrateur
 * Purpose: Defines the Class Commentaires
 ***********************************************************************/

import java.util.*;

/** @pdOid 5495870f-dfad-4eb2-9063-5987ef7d907e */
public class Commentaires {
   /** @pdOid bccffcd2-f19d-4fed-b027-b82d05f7083d */
   private int idCommentaire;
   /** @pdOid 3a27e555-907d-4a3b-9d52-0757a1543148 */
   private String texteCommentaire;
   /** @pdOid 6327e490-78d2-4189-b555-3323afc167d9 */
   private java.util.Date dateCommentaire;
   /** @pdOid 8e90dd85-06d6-4d57-8a83-24e7c7739700 */
   private String emailCommentaire;

}