/***********************************************************************
 * Module:  Articles.java
 * Author:  Administrateur
 * Purpose: Defines the Class Articles
 ***********************************************************************/

import java.util.*;

/** @pdOid 0666e032-958f-476c-ac70-3dade393aee1 */
public class Articles {
   /** @pdOid 11cfa8ee-8536-4ff1-b131-eacbda1f3dee */
   private int idArticle;
   /** @pdOid 263fa89c-5e99-4705-8b01-33dc89be5af2 */
   private String texteArticle;
   /** @pdOid 9be2a2f7-7ada-4bb2-a055-259f0b7c6b9d */
   private java.util.Date datePublication;

}