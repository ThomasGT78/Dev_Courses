/***********************************************************************
 * Module:  Clients.java
 * Author:  Administrateur
 * Purpose: Defines the Class Clients
 ***********************************************************************/

import java.util.*;

/** @pdOid 8e7cee82-e113-4f2c-972d-c50747c05366 */
public class Clients {
   /** @pdOid 472c19ff-01ed-451a-b793-54972f567e60 */
   public long idClient;
   /** @pdOid 1bbb9437-00b1-4061-a8c7-91717de44c78 */
   public java.lang.String nom;
   /** @pdOid c68376cc-9ebe-4bdc-a89e-d0e82b73d3c4 */
   public java.lang.String prenom;
   /** @pdOid a13b77f8-b582-49e8-a488-92ad8f5c6658 */
   public java.lang.String adresse;
   /** @pdOid cb31b0f5-8e14-4b6f-a4bb-2022b9085c45 */
   public java.util.Date dateNaissance;
   /** @pdOid 43764e49-399b-488c-9014-1bcc53ce1df5 */
   public java.lang.String cp;
   
   /** @pdRoleInfo migr=no name=Cdes assc=fkCdesClient coll=java.util.Collection impl=java.util.HashSet mult=0..* */
   public java.util.Collection<Cdes> cdes;
   /** @pdRoleInfo migr=no name=Villes assc=fkClientsCp mult=1..1 side=A */
   public Villes villes;
   
   
   /** @pdGenerated default getter */
   public java.util.Collection<Cdes> getCdes() {
      if (cdes == null)
         cdes = new java.util.HashSet<Cdes>();
      return cdes;
   }
   
   /** @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorCdes() {
      if (cdes == null)
         cdes = new java.util.HashSet<Cdes>();
      return cdes.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newCdes */
   public void setCdes(java.util.Collection<Cdes> newCdes) {
      removeAllCdes();
      for (java.util.Iterator iter = newCdes.iterator(); iter.hasNext();)
         addCdes((Cdes)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newCdes */
   public void addCdes(Cdes newCdes) {
      if (newCdes == null)
         return;
      if (this.cdes == null)
         this.cdes = new java.util.HashSet<Cdes>();
      if (!this.cdes.contains(newCdes))
      {
         this.cdes.add(newCdes);
         newCdes.setClients(this);      
      }
   }
   
   /** @pdGenerated default remove
     * @param oldCdes */
   public void removeCdes(Cdes oldCdes) {
      if (oldCdes == null)
         return;
      if (this.cdes != null)
         if (this.cdes.contains(oldCdes))
         {
            this.cdes.remove(oldCdes);
            oldCdes.setClients((Clients)null);
         }
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllCdes() {
      if (cdes != null)
      {
         Cdes oldCdes;
         for (java.util.Iterator iter = getIteratorCdes(); iter.hasNext();)
         {
            oldCdes = (Cdes)iter.next();
            iter.remove();
            oldCdes.setClients((Clients)null);
         }
      }
   }
   /** @pdGenerated default parent getter */
   public Villes getVilles() {
      return villes;
   }
   
   /** @pdGenerated default parent setter
     * @param newVilles */
   public void setVilles(Villes newVilles) {
      if (this.villes == null || !this.villes.equals(newVilles))
      {
         if (this.villes != null)
         {
            Villes oldVilles = this.villes;
            this.villes = null;
            oldVilles.removeClients(this);
         }
         if (newVilles != null)
         {
            this.villes = newVilles;
            this.villes.addClients(this);
         }
      }
   }

}