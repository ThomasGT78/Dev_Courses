/***********************************************************************
 * Module:  Pays.java
 * Author:  Administrateur
 * Purpose: Defines the Class Pays
 ***********************************************************************/

import java.util.*;

/** @pdOid de859027-acdf-412d-b71b-f0e756169cca */
public class Pays {
   /** @pdOid 492aea24-414b-407b-9489-1c28a632b846 */
   public java.lang.String idPays;
   /** @pdOid 1e280547-92aa-45b7-8e06-90960af6a5ea */
   public java.lang.String nomPays;
   
   /** @pdRoleInfo migr=no name=Villes assc=fkVillesPays coll=java.util.Collection impl=java.util.HashSet mult=0..* */
   public java.util.Collection<Villes> villes;
   
   
   /** @pdGenerated default getter */
   public java.util.Collection<Villes> getVilles() {
      if (villes == null)
         villes = new java.util.HashSet<Villes>();
      return villes;
   }
   
   /** @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorVilles() {
      if (villes == null)
         villes = new java.util.HashSet<Villes>();
      return villes.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newVilles */
   public void setVilles(java.util.Collection<Villes> newVilles) {
      removeAllVilles();
      for (java.util.Iterator iter = newVilles.iterator(); iter.hasNext();)
         addVilles((Villes)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newVilles */
   public void addVilles(Villes newVilles) {
      if (newVilles == null)
         return;
      if (this.villes == null)
         this.villes = new java.util.HashSet<Villes>();
      if (!this.villes.contains(newVilles))
      {
         this.villes.add(newVilles);
         newVilles.setPays(this);      
      }
   }
   
   /** @pdGenerated default remove
     * @param oldVilles */
   public void removeVilles(Villes oldVilles) {
      if (oldVilles == null)
         return;
      if (this.villes != null)
         if (this.villes.contains(oldVilles))
         {
            this.villes.remove(oldVilles);
            oldVilles.setPays((Pays)null);
         }
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllVilles() {
      if (villes != null)
      {
         Villes oldVilles;
         for (java.util.Iterator iter = getIteratorVilles(); iter.hasNext();)
         {
            oldVilles = (Villes)iter.next();
            iter.remove();
            oldVilles.setPays((Pays)null);
         }
      }
   }

}