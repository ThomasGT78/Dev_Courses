/***********************************************************************
 * Module:  Ligcdes.java
 * Author:  Administrateur
 * Purpose: Defines the Class Ligcdes
 ***********************************************************************/

import java.util.*;

/** @pdOid 4e20a4a2-c9e0-450d-a7e3-5bc47c16caf7 */
public class Ligcdes {
   /** @pdOid c1321212-93c7-4425-97f5-1ee4ffbfbd4a */
   private int idLigCdes;
   
   /** @pdOid 55e75978-b30e-4268-899d-14b57d691488 */
   public int qte;

}