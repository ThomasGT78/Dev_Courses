/***********************************************************************
 * Module:  Villes.java
 * Author:  Administrateur
 * Purpose: Defines the Class Villes
 ***********************************************************************/

import java.util.*;

/** @pdOid 7ecd1f7c-64f5-4933-b81a-0d062ee8cfac */
public class Villes {
   /** @pdOid 83be37de-3a59-474e-baec-c0fc4e79cbfa */
   public java.lang.String cp;
   /** @pdOid 12a90f62-134e-4540-a7bd-3c4fae9e7e7a */
   public java.lang.String nomVille;
   /** @pdOid 1d2aa8bf-079f-4b0b-bc58-d6609ab619bf */
   public java.lang.String site;
   /** @pdOid 25240383-5ead-4059-aa87-94eaa3a1df29 */
   public java.lang.String photo;
   /** @pdOid accae19e-6473-4b12-a290-440a86b32087 */
   public java.lang.String idPays;
   
   /** @pdRoleInfo migr=no name=Clients assc=fkClientsCp coll=java.util.Collection impl=java.util.HashSet mult=0..* */
   public java.util.Collection<Clients> clients;
   /** @pdRoleInfo migr=no name=Pays assc=fkVillesPays mult=1..1 side=A */
   public Pays pays;
   
   
   /** @pdGenerated default getter */
   public java.util.Collection<Clients> getClients() {
      if (clients == null)
         clients = new java.util.HashSet<Clients>();
      return clients;
   }
   
   /** @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorClients() {
      if (clients == null)
         clients = new java.util.HashSet<Clients>();
      return clients.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newClients */
   public void setClients(java.util.Collection<Clients> newClients) {
      removeAllClients();
      for (java.util.Iterator iter = newClients.iterator(); iter.hasNext();)
         addClients((Clients)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newClients */
   public void addClients(Clients newClients) {
      if (newClients == null)
         return;
      if (this.clients == null)
         this.clients = new java.util.HashSet<Clients>();
      if (!this.clients.contains(newClients))
      {
         this.clients.add(newClients);
         newClients.setVilles(this);      
      }
   }
   
   /** @pdGenerated default remove
     * @param oldClients */
   public void removeClients(Clients oldClients) {
      if (oldClients == null)
         return;
      if (this.clients != null)
         if (this.clients.contains(oldClients))
         {
            this.clients.remove(oldClients);
            oldClients.setVilles((Villes)null);
         }
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllClients() {
      if (clients != null)
      {
         Clients oldClients;
         for (java.util.Iterator iter = getIteratorClients(); iter.hasNext();)
         {
            oldClients = (Clients)iter.next();
            iter.remove();
            oldClients.setVilles((Villes)null);
         }
      }
   }
   /** @pdGenerated default parent getter */
   public Pays getPays() {
      return pays;
   }
   
   /** @pdGenerated default parent setter
     * @param newPays */
   public void setPays(Pays newPays) {
      if (this.pays == null || !this.pays.equals(newPays))
      {
         if (this.pays != null)
         {
            Pays oldPays = this.pays;
            this.pays = null;
            oldPays.removeVilles(this);
         }
         if (newPays != null)
         {
            this.pays = newPays;
            this.pays.addVilles(this);
         }
      }
   }

}