/***********************************************************************
 * Module:  Cdes.java
 * Author:  Administrateur
 * Purpose: Defines the Class Cdes
 ***********************************************************************/

import java.util.*;

/** @pdOid 42899277-23c4-4896-9801-4ea9e4d0a145 */
public class Cdes {
   /** @pdOid 19360a74-bfec-4484-8496-92ef55ec0290 */
   public long idCde;
   /** @pdOid dd1d8cbe-9d3a-4a5d-afe0-d2b87688057b */
   public java.util.Date dateCde;
   /** @pdOid ef43e087-eb07-47af-9dbd-bf5dea7d51f6 */
   public int idClient;
   
   /** @pdRoleInfo migr=no name=Clients assc=fkCdesClient mult=1..1 side=A */
   public Clients clients;
   
   
   /** @pdGenerated default parent getter */
   public Clients getClients() {
      return clients;
   }
   
   /** @pdGenerated default parent setter
     * @param newClients */
   public void setClients(Clients newClients) {
      if (this.clients == null || !this.clients.equals(newClients))
      {
         if (this.clients != null)
         {
            Clients oldClients = this.clients;
            this.clients = null;
            oldClients.removeCdes(this);
         }
         if (newClients != null)
         {
            this.clients = newClients;
            this.clients.addCdes(this);
         }
      }
   }

}