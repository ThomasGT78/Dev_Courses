/***********************************************************************
 * Module:  Produits.java
 * Author:  Administrateur
 * Purpose: Defines the Class Produits
 ***********************************************************************/

import java.util.*;

/** @pdOid 5e295275-a395-4a62-8733-97c79247197d */
public class Produits {
   /** @pdOid 5dc46ec7-6886-4190-998f-ffbf07864500 */
   public long idProduit;
   /** @pdOid 94ddd933-3267-44a5-b6aa-fde13fca4dc0 */
   public java.lang.String designation;
   /** @pdOid 0c8790d6-09b5-42b4-8640-68a36d959b07 */
   public double prix;
   /** @pdOid bbd61878-a586-4821-ab43-98e979b90186 */
   public int qteStockee = 0;
   /** @pdOid a0f8f2df-78bb-4383-a0d4-e254be7dcf52 */
   public java.lang.String photo;

}