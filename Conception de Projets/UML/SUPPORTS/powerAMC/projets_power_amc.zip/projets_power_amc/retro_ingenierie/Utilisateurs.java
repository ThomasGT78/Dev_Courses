/***********************************************************************
 * Module:  Utilisateurs.java
 * Author:  Administrateur
 * Purpose: Defines the Class Utilisateurs
 ***********************************************************************/

import java.util.*;

/** @pdOid 3415e462-4e83-43bd-96ed-2ef438139ea6 */
public class Utilisateurs {
   /** @pdOid ba2db864-9232-4432-b616-487e5a4325c1 */
   public java.lang.String pseudo;
   /** @pdOid e5f78ae7-d928-4f3b-a71a-7e24554213da */
   public java.lang.String mdp;
   /** @pdOid 210c9eaf-f991-4040-b93a-385cd0fc806d */
   public java.lang.String email;
   /** @pdOid 17ac7bd7-d1bc-43ce-9b35-4b51523976d7 */
   public java.lang.String qualite;

}